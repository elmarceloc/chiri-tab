# Chiri on new Tab!
A Google Chrome Extension that shows a random photo of my cat in a new tab. Feel free to fork this and replace the images with photos of your pet, boyfriend or wharever you want!

![image (45)](https://user-images.githubusercontent.com/73359763/167586406-05333561-8f61-4136-a296-5f7be2de0f76.png)